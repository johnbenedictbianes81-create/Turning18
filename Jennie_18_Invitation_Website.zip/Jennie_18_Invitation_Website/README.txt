Jennie's 18th Birthday Invitation Website

Open index.html in any modern web browser to view the invitation.

The page is self-contained: the photos are embedded in the HTML, so no image files are required.
